echarts-optimize ./
rm dist/echarts-x-all.js
rm source/echarts-x-all.js
